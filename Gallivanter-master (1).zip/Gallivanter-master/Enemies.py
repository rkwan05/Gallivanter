         
  
import pygame
    
class Enemies:
    def __init__(self, health, damage):
        self.health = health
        self.damage = damage

